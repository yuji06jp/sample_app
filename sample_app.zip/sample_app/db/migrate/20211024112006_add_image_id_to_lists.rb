class AddImageIdToLists < ActiveRecord::Migration[5.2]
  def change
    add_column :lists, :image_id, :str
    add_column :lists, :ing, :string
  end
end
