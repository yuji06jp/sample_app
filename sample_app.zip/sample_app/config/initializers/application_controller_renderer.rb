# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'ffee475871fb1def2390f79c1a0e3134c64d63580d7df31ac5f28cc028c04cdb551b6f845bc2728e02a1d1dbf861e9688c82ff74fb4d058d75543515454140a7'
